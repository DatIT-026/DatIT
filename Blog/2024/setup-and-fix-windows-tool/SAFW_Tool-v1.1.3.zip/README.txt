﻿	-------------------------INFORMATION-------------------------

*NOTE: YOU MUST RUN AS ADMINISTRATOR BEFORE USING THIS TOOL.

Program information and updates:

v1.1.3 (Coming Soon)

v1.1.2 (Latest Version)

- Removed features: Date & Time, Region.
- Added new feature: WiFi Password Viewer 
(View passwords of previously connected Wi-Fi networks on Windows).
- Updated and improved several features: 
  • Redesigned Interface.


v1.1.1

- New Feature: Enable/Disable Windows Update.
- Updates and Improvements:
  • Wi-Fi troubleshooting tool enhancements.
  • Updated link to Microsoft Activation Scripts AIO (MAS).
- Fixed UI and compatibility issues (Windows 10, Windows 11).
- The Update feature has been improved.
- Enhanced tool performance and optimization.


v1.1.0

- Integration with Microsoft Activation Scripts AIO tool.
- Enhanced Activation Status feature.
- New UI compatible with Windows 7, 10, and 11.
- Improved Update feature.
- Performance enhancements.

--------------------------------------------------------
Program: SETUP AND FIX WINDOWS TOOL
For Support:
- FaceBook 1: https://www.facebook.com/hanguyentiendat2006
- FaceBook 2: https://www.facebook.com/KiyoshiDatto/
--------------------------------------------------------------------------------
©Copyright by FireHelper Team. All right reserved.